from lambda_py.lambda_function import handler


def lambda_handler(event, context):
    handler(event)
